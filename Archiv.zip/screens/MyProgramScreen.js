import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import { Image } from 'react-native';
import Header from '../components/Header';
import { loadFromCache, removeFromCache } from '../utils/cache';
import notifee, { TimestampTrigger, TriggerType } from '@notifee/react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Ionicons from 'react-native-vector-icons/Ionicons';
export default function MyProgramScreen() {
  const [events, setEvents] = useState([]);
  const [artistIds, setArtistIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const isFocused = useIsFocused();
  const navigation = useNavigation();

  const cachedEventsRef = useRef(null);
  const cachedArtistsRef = useRef(null);


  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    const load = async () => {
      const saved = await AsyncStorage.getItem('notificationsEnabled');
      setNotificationsEnabled(saved === 'true');
    };
    load();
  }, []);

  useEffect(() => {
    const loadData = async () => {
      try {
        const favorites = (await loadFromCache('myArtists')) || [];

        const cachedProgram = await loadFromCache('cachedProgramData');

        const numericArtistIds = favorites.map(id => parseInt(id));
        const myEvents = cachedProgram?.filter(e =>
          numericArtistIds.includes(parseInt(e.interpret_id))
        ) || [];

        setArtistIds(favorites);
        setEvents(myEvents);

        cachedEventsRef.current = myEvents;
        cachedArtistsRef.current = favorites;
      } catch (error) {
        console.error('❌ Error loading favorites or events:', error);
      } finally {
        setLoading(false);
      }
    };

    if (isFocused) {
      loadData();
    }
  }, [isFocused]);


const scheduleNotifications = async () => {
  try {
    const storedArtists = await AsyncStorage.getItem('myArtists');
    const artistIds = storedArtists ? JSON.parse(storedArtists) : [];

    const programData = await loadFromCache('cachedProgramData'); // ⬅️ správný název cache
    if (!programData || programData.length === 0) {
      console.warn('⚠️ Žádná data v cachedProgramData. Notifikace nebudou naplánovány.');
      return;
    }

    console.log("📦 Načteno eventů:", programData.length);

    const now = Date.now();
    let count = 0;

    for (const artist of artistIds) {
      const event = programData.find(
        (item) =>
          String(item.interpret_id) === String(artist) ||
          String(item.artist_id) === String(artist)
      );

      if (!event) {
        console.warn(`⚠️ Nenalezen event pro artist_id: ${artist}`);
        continue;
      }

      const startRaw = event.start || event.time_from;
      const startTime = new Date(startRaw).getTime();
      const triggerTime = startTime - 15 * 60 * 1000;

      if (isNaN(startTime)) {
        console.warn(`❌ Neplatný čas pro interpreta ${event.name || 'neznámý'}`);
        continue;
      }

      if (triggerTime > now) {
        const trigger = {
          type: TriggerType.TIMESTAMP,
          timestamp: triggerTime,
        };

        await notifee.createTriggerNotification(
          {
            title: 'Za chvíli to začne!',
            body: `${event.name || 'Neznámý interpret'} začíná za 15 minut na ${event.stage || event.stage_name || 'neznámá stage'}`,
            android: {
              channelId: 'default',
              smallIcon: 'ic_launcher',
            },
          },
          trigger
        );

        count++;
      } else {
        console.log(`⏱️ Event ${event.name} už začal nebo je příliš brzy, triggerTime: ${new Date(triggerTime).toISOString()}, now: ${new Date(now).toISOString()}`);
      }
    }

    console.log(`🎯 Celkem naplánovaných notifikací: ${count}`);
  } catch (err) {
    console.error('❌ Chyba při plánování notifikací:', err);
  }
};




  const toggleNotifications = async () => {
    if (!notificationsEnabled) {
      await notifee.requestPermission();
      await scheduleNotifications();
      await AsyncStorage.setItem('notificationsEnabled', 'true');
      setNotificationsEnabled(true);
    } else {
      await notifee.cancelAllNotifications();
      await AsyncStorage.setItem('notificationsEnabled', 'false');
      setNotificationsEnabled(false);
    }
  };

  async function debugScheduledNotifications() {
    const ids = await notifee.getTriggerNotificationIds();
    console.log(`🕒 Načteno ${ids.length} naplánovaných notifikací`);

    for (const id of ids) {
      const notif = await notifee.getTriggerNotification(id);
      console.log(`🔔 ID: ${id}`);
      console.log('📋 Title:', notif.notification.title);
      console.log('📝 Body:', notif.notification.body);
      console.log('🗓️ Trigger:', notif.trigger);
    }
  }  

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#EA5178" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.background}>
      <Header title="Můj program" />

      <View style={styles.content}>
        {Array.isArray(events) ? (
          events.length === 0 ? (
            <Text style={styles.noFavorites}>Nemáš zatím uložené žádné interprety.</Text>
          ) : (
            events
              .slice()
              .sort((a, b) => new Date(a.start) - new Date(b.start))
              .map((item) => {
                const [datePart, timePart] = item.start.split('T');
                const endTime = item.end.split('T')[1];

                const uri = item.photo_artist?.url;

                const startDateTime = new Date(item.start);
                let dayLabel = '';
                if (startDateTime.getDay() === 5) {
                  dayLabel = 'Pátek';
                } else if (startDateTime.getDay() === 6) {
                  dayLabel = 'Sobota';
                } else if (startDateTime.getDay() === 0) {
                  dayLabel = 'Neděle';
                }

                return (
                  <TouchableOpacity
                    key={item.interpret_id}
                    style={styles.eventCard}
                    onPress={() => navigation.navigate('ArtistDetail', { id: parseInt(item.interpret_id) })}
                  >
                    <View style={styles.eventRow}>

                    {uri ? (
                      <Image
                        source={{ uri }}
                        style={styles.artistPhoto}
                        resizeMode="cover"           // místo contentFit
                      />
                    ) : (
                      <View style={[styles.artistPhoto, styles.placeholder]} />
                    )}


                      <View style={styles.eventInfo}>
                        <Text style={styles.name}>
                          {item.name.length > 29 ? item.name.substring(0, 29) + '...' : item.name}
                        </Text>
                        <Text style={styles.stage}>{item.stage_name}</Text>
                        <Text style={styles.time}>
                          {dayLabel} {timePart} - {endTime}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              })
          )
        ) : (
          <Text style={{ color: 'red', textAlign: 'center', marginVertical: 20 }}>
            ❗ Nepodařilo se načíst program. Pravděpodobně chyba v datech.
          </Text>
        )}

        <TouchableOpacity
          onPress={toggleNotifications}
          style={{
            position: 'absolute',
            bottom: 20,
            right: 20,
            backgroundColor: notificationsEnabled ? '#21AAB0' : '#999',
            borderRadius: 28,
            padding: 14,
            elevation: 5,
            shadowColor: '#000',
            shadowOpacity: 0.3,
            shadowOffset: { width: 0, height: 3 },
            shadowRadius: 4,
          }}
        >
          <Ionicons
            name={notificationsEnabled ? 'notifications' : 'notifications-off-outline'}
            size={28}
            color="#ffffff"
          />
        </TouchableOpacity>
<TouchableOpacity onPress={debugScheduledNotifications}>
  <Text style={{ color: 'white' }}>Vypsat naplánované notifikace</Text>
</TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: '#002239',
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 30,
  },
  eventCard: {
    backgroundColor: '#0A3652',
    padding: 15,
    marginBottom: 15,
  },
  name: {
    color: 'white',
    fontWeight: '700',
    fontSize: 18,
    marginBottom: 5,
  },
  stage: {
    color: 'white',
    fontSize: 14,
    marginBottom: 5,
  },
  time: {
    color: '#EA5178',
    fontSize: 14,
    fontWeight: '600',
  },
  clearButton: {
    marginTop: 20,
    backgroundColor: '#FF3B30',
    padding: 12,
  },
  clearButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  noFavorites: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
    marginVertical: 30,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#002239',
  },
  eventRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  thumbnail: {
    width: 60,
    height: 60,
    marginRight: 15,
  },
  eventText: {
    flex: 1,
  },
  artistPhoto: {
    width: 60,
    height: 60,
    marginRight: 15,
  },
  placeholder: {
    backgroundColor: '#ccc',     // nebo jakákoliv barva záložky
  },
});
